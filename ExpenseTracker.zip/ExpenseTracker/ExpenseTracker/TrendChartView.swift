import SwiftUI
import Charts

struct TrendData: Identifiable {
    let id = UUID()
    let date: Date
    let total: Double
}

struct TrendChartView: View {

    @EnvironmentObject var vm: ExpenseViewModel

    @State private var selectedFilter = "Daily"
    let filters = ["Daily", "Weekly", "Monthly"]

    var body: some View {

        let chartData = getChartData()

        VStack {

            // ✅ Toggle
            Picker("Filter", selection: $selectedFilter) {
                ForEach(filters, id: \.self) { filter in
                    Text(filter)
                }
            }
            .pickerStyle(.segmented)
            .padding()

            // ✅ Chart
            if chartData.isEmpty {
                Text("No Data")
                    .foregroundColor(.gray)
            } else {

                Chart(chartData) { item in
                    LineMark(
                        x: .value("Date", item.date),
                        y: .value("Amount", item.total)
                    )
                }
                .frame(height: 300)
                .animation(.easeInOut, value: selectedFilter) // 🔥 smooth update
            }
        }
        .padding()
    }

    // ✅ WORKING LOGIC
    func getChartData() -> [TrendData] {

        var result: [Date: Double] = [:]   // ✅

        

        let outputFormatter = DateFormatter()

        for exp in vm.expenses {

            let date = exp.date   // ✅ already Date

            switch selectedFilter {

            case "Daily":
                outputFormatter.dateFormat = "MMM d"

            case "Weekly":
                outputFormatter.dateFormat = "YYYY-'W'ww"

            case "Monthly":
                outputFormatter.dateFormat = "MMM yyyy"

            default:
                outputFormatter.dateFormat = "MMM d"
            }

            let calendar = Calendar.current

            let keyDate: Date

            switch selectedFilter {

            case "Daily":
                keyDate = calendar.startOfDay(for: date)

            case "Weekly":
                keyDate = calendar.dateInterval(of: .weekOfYear, for: date)?.start ?? date

            case "Monthly":
                keyDate = calendar.date(from: calendar.dateComponents([.year, .month], from: date)) ?? date

            default:
                keyDate = date
            }

            result[keyDate, default: 0] += exp.amount}

        return result.map {
            TrendData(date: $0.key, total: $0.value)
        }
        .sorted { $0.date < $1.date }
    }
}
