import Foundation

struct Trend: Codable, Identifiable {
    var id = UUID()
    var date: String?     // ✅ FIX (was String)
    var amount: Double
}
