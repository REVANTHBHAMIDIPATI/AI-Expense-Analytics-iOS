import SwiftUI

@main
struct ExpenseTrackerApp: App {

    @StateObject var vm = ExpenseViewModel()   // ✅ CREATE HERE

    var body: some Scene {
        WindowGroup {
            MainTabView()
                .environmentObject(vm)        // ✅ INJECT HERE
        }
    }
}
