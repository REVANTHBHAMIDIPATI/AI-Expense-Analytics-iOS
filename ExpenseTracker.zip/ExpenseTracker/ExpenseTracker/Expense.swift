import Foundation

struct Expense: Codable, Identifiable {
    var id: String?
    var title: String?
    var amount: Double
    var category: String
    var createdAt: Date?
    var date: Date

    enum CodingKeys: String, CodingKey {
        case id = "_id"
        case title, amount, category, createdAt, date
    }
}
