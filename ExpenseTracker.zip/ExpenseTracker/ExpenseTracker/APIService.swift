import Foundation

class APIService {
    static let shared = APIService()

    let baseURL = "http://127.0.0.1:5001"

    // FETCH
    func fetchExpenses(completion: @escaping ([Expense]) -> Void) {
        guard let url = URL(string: "\(baseURL)/expenses") else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else { return }

            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601

            let expenses = try? decoder.decode([Expense].self, from: data)

            DispatchQueue.main.async {
                completion(expenses ?? [])
            }
        }.resume()
    }

    // ADD
    func addExpense(expense: Expense, completion: @escaping () -> Void) {
        guard let url = URL(string: "\(baseURL)/expenses") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        req.httpBody = try? JSONEncoder().encode(expense)

        URLSession.shared.dataTask(with: req) { _, _, _ in
            DispatchQueue.main.async {
                completion()
            }
        }.resume()
    }

    // DELETE
    func deleteExpense(id: String, completion: @escaping () -> Void) {
        guard let url = URL(string: "\(baseURL)/expenses/\(id)") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"

        URLSession.shared.dataTask(with: req) { _, _, _ in
            DispatchQueue.main.async {
                completion()
            }
        }.resume()
    }

    func fetchTrends(filter: String, completion: @escaping ([Trend]) -> Void) {

        let urlString = "http://localhost:5001/expenses/analytics/trends?filter=\(filter)"
        print("🌐 Calling:", urlString)

        guard let url = URL(string: urlString) else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in

            guard let data = data else { return }

            do {
                let decoded = try JSONDecoder().decode([Trend].self, from: data)
                DispatchQueue.main.async {
                    completion(decoded)
                }
            } catch {
                print("❌ Decode error:", error)
            }

        }.resume()
    }
    // UPDATE
    func updateExpense(id: String, expense: Expense, completion: @escaping () -> Void) {
        guard let url = URL(string: "\(baseURL)/expenses/\(id)") else { return }

        var req = URLRequest(url: url)
        req.httpMethod = "PUT"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        req.httpBody = try? JSONEncoder().encode(expense)

        URLSession.shared.dataTask(with: req) { _, _, _ in
            DispatchQueue.main.async {
                completion()
            }
        }.resume()
    }
}
