import Foundation

struct CategoryItem: Identifiable, Codable {
    var id = UUID()
    
    let category: String
    let amount: Double
}
