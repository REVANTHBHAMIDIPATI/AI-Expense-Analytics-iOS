import SwiftUI

struct EditExpenseView: View {

    @Environment(\.dismiss) var dismiss
    @State var expense: Expense
    var onSave: (Expense) -> Void

    let categories = ["Food", "Travel", "Bills", "Entertainment"]

    var body: some View {
        VStack(spacing: 20) {

            Text("Edit Expense")
                .font(.title)
                .foregroundColor(.white)

            TextField("Title", text: Binding(
                get: { expense.title ?? "" },
                set: { expense.title = $0 }
            ))
            .textFieldStyle(.roundedBorder)

            TextField("Amount", value: $expense.amount, format: .number)
                .keyboardType(.decimalPad)
                .textFieldStyle(.roundedBorder)

            Picker("Category", selection: $expense.category) {
                ForEach(categories, id: \.self) { cat in
                    Text(cat)
                }
            }
            .pickerStyle(.menu)

            Button("Update") {
                print("Updating:", expense)   // debug
                onSave(expense)              // ✅ send back
                dismiss()
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .background(Color.black.ignoresSafeArea())
    }
}
