//
//  HomeView.swift
//  ExpenseTracker
//
//  Created by Revanth B S P on 8/8/26.
//


import SwiftUI

struct HomeView: View {
    
    @EnvironmentObject var vm: ExpenseViewModel
    
    var totalExpense: Double {
        vm.expenses.reduce(0) { $0 + $1.amount }
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                
                Text("Total Expenses")
                    .font(.title2)
                    .foregroundColor(.gray)
                
                Text("$\(totalExpense, specifier: "%.2f")")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                
                Spacer()
            }
            .padding()
            .navigationTitle("Dashboard")
            .onAppear {
                vm.fetchExpenses()
            }
        }
    }
}
