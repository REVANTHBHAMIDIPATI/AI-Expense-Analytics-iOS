import SwiftUI

struct TrendView: View {

    @EnvironmentObject var vm: ExpenseViewModel
    @State var selectedFilter = "daily"

    var body: some View {

        VStack {

            // 🔥 FILTER TOGGLE
            Picker("Filter", selection: $selectedFilter) {
                Text("Daily").tag("daily")
                Text("Monthly").tag("monthly")
            }
            .pickerStyle(.segmented)
            .padding()

            // 🔥 SHOW DATA FIRST (DEBUG)
            if vm.trends.isEmpty {
                Text("No Data Found")
                    .foregroundColor(.gray)
            } else {

                List(vm.trends) { trend in
                    HStack {
                        Text(trend.date ?? "No Date")   // ✅ SAFE
                        Spacer()
                        Text("$\(trend.amount, specifier: "%.2f")")
                    }
                }
            }
        }
        .onAppear {
            print("🔥 Loading trends:", selectedFilter)
            vm.fetchTrends()
        }
        .onChange(of: selectedFilter) { newValue in
            print("🔥 Changed filter:", newValue)
            vm.fetchTrends()
        }
    }
}
