import SwiftUI

struct AddExpenseView: View {

    @Environment(\.dismiss) var dismiss   // ✅ FIXED
    @EnvironmentObject var vm: ExpenseViewModel

    @State private var title = ""
    @State private var amount = ""
    @State private var category = "Food"

    let categories = ["Food", "Travel", "Bills", "Entertainment", "Shopping", "Credit Cards"]

    var body: some View {
        VStack(spacing: 20) {

            TextField("Title", text: $title)
                .textFieldStyle(.roundedBorder)

            TextField("Amount", text: $amount)
                .keyboardType(.decimalPad)
                .textFieldStyle(.roundedBorder)

            VStack(alignment: .leading, spacing: 8) {

                Text("Category")
                    .foregroundColor(.gray)

                Picker("Category", selection: $category) {
                    ForEach(categories, id: \.self) { cat in
                        Text(cat).tag(cat)
                    }
                }
                .pickerStyle(.menu)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color(.systemGray6))
                .cornerRadius(10)
            }

            // ✅ CLEAN SAVE BUTTON
            Button("Save") {

                print("🔥 Save clicked")

                let amountValue = Double(amount) ?? 0

                if title.isEmpty || amountValue <= 0 {
                    print("Invalid input")
                } else {

                    let newExpense = Expense(
                        id: nil,
                        title: title,
                        amount: amountValue,
                        category: category,
                        createdAt: nil,
                        date: Date()
                    )

                    vm.addExpense(expense: newExpense)   // ✅ correct
                    dismiss()                            // ✅ correct
                }
            }
            .buttonStyle(.borderedProminent)

        }
        .padding()
    }
}
