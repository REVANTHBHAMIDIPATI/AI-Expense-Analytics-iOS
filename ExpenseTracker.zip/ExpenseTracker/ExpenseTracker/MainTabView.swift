import SwiftUI
struct MainTabView: View {

    @EnvironmentObject var vm: ExpenseViewModel

    var body: some View {
        TabView {

            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house")
                }

            ExpenseListView()   // ✅ PASS VM
                .tabItem {
                    Label("Expenses", systemImage: "list.bullet")
                }

            AddExpenseView()  // ✅ FIX HERE
                .tabItem {
                    Label("Add", systemImage: "plus")
                }

            TrendChartView()
                .tabItem {
                    Label("Trends", systemImage: "chart.bar")
                }
        }
    }
}
