import Foundation
import Combine

class ExpenseViewModel: ObservableObject {

    // ✅ SINGLE SOURCE OF TRUTH
    @Published var expenses: [Expense] = []
    @Published var trends: [Trend] = []
    @Published var isLoading = false
    let api = APIService.shared

    var totalAmount: Double {
        expenses.reduce(0) { $0 + $1.amount }
    }

    // MARK: - FETCH EXPENSES
    func fetchExpenses() {
        api.fetchExpenses { data in
            DispatchQueue.main.async {
                self.expenses = data
            }
        }
    }

    // MARK: - FETCH TRENDS
    func fetchTrends() {
        guard let url = URL(string: "http://localhost:5001/expenses/analytics/trends?filter=daily") else { return }

        URLSession.shared.dataTask(with: url) { data, _, _ in
            guard let data = data else { return }

            do {
                let decoded = try JSONDecoder().decode([Trend].self, from: data)
                DispatchQueue.main.async {
                    self.trends = decoded
                }
            } catch {
                print("❌ trend decode error")
            }
        }.resume()
    }

    // MARK: - ADD
    func addExpense(expense: Expense) {
        // ✅ 1. Instant UI update
        DispatchQueue.main.async {
            self.expenses.insert(expense, at: 0)
        }

        // ✅ 2. Save to backend
        api.addExpense(expense: expense) {
            DispatchQueue.main.async {
                self.fetchExpenses()   // 🔥 sync with backend
            }
        }
    }

    // MARK: - DELETE
    func deleteExpense(at offsets: IndexSet) {
        offsets.forEach { index in
            let id = expenses[index].id ?? ""
            api.deleteExpense(id: id) {
                self.fetchExpenses()
            }
        }
    }

    // MARK: - UPDATE
    func updateExpense(expense: Expense) {
        guard let id = expense.id else { return }

        guard let url = URL(string: "http://localhost:5001/expenses/\(id)") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        do {
            request.httpBody = try JSONEncoder().encode(expense)
        } catch {
            print("❌ Encoding failed")
            return
        }

        URLSession.shared.dataTask(with: request) { _, _, _ in
            DispatchQueue.main.async {
                self.fetchExpenses()
            }
        }.resume()
    }
}
