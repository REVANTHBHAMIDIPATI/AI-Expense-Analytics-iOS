import Foundation

struct TrendItem: Identifiable, Codable {
    let id = UUID()
    let date: String
    let category: String
    let total: Double

    enum CodingKeys: String, CodingKey {
        case date, category, total
    }
}
