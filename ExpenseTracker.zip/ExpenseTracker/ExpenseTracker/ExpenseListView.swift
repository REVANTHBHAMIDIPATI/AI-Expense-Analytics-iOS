import SwiftUI

struct ExpenseListView: View {

    @EnvironmentObject var vm: ExpenseViewModel

    var body: some View {
        NavigationView {
            List {
                ForEach(vm.expenses) { expense in

                    NavigationLink(
                        destination: EditExpenseView(
                            expense: expense,
                            onSave: { updatedExpense in
                                vm.updateExpense(expense: updatedExpense)   // ✅ FIX
                            }
                        )
                    ) {

                        VStack(alignment: .leading) {

                            Text(expense.title ?? "No Title")
                                .font(.headline)

                            Text("$\(expense.amount, specifier: "%.2f")")
                                .foregroundColor(.gray)

                            Text(expense.category)
                                .font(.subheadline)
                        }
                    }
                }
                .onDelete(perform: vm.deleteExpense)
            }
            .navigationTitle("Expenses")
            .onAppear {
                vm.fetchExpenses()
            }
        }
    }
}
