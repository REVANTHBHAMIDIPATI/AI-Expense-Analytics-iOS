//
//  Category.swift
//  ExpenseTracker
//
//  Created by Revanth B S P on 8/8/26.
//


import Foundation

enum Category: String, CaseIterable, Identifiable {
    case food = "Food"
    case travel = "Travel"
    case shopping = "Shopping"
    case bills = "Bills"
    case entertainment = "Entertainment"
    
    var id: String { self.rawValue }
}